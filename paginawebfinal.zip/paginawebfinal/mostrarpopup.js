function mostrarPopup() {
    document.getElementById("miPopup").style.display = "block";
  }
  
  // Función para cerrar la pantalla emergente
  function cerrarPopup() {
    document.getElementById("miPopup").style.display = "none";
  }